# == Schema Information
#
# Table name: songs
#
#  id         :bigint           not null, primary key
#  name       :string           not null
#  length     :integer          not null
#  album_id   :bigint           not null
#  created_at :datetime         not null
#  updated_at :datetime         not null
#

require 'rails_helper'

RSpec.describe Song, type: :model do
  subject(:song) { Song.first }

  it "is associated with an album" do
    expect(song.album.name).to eq("Selected Ambient Works 85-92")
  end

  it "is associated with playlist tracks" do
    expect(song.playlist_tracks.first.song_id).to eq(song.id)
  end

  it "is associated with an artist" do
    expect(song.artist.username).to eq("Aphex-Twin")
  end

  it "can be successfully destroyed" do
    expect { song.destroy }.not_to raise_error
  end
end