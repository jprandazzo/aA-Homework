# == Schema Information
#
# Table name: users
#
#  id         :bigint           not null, primary key
#  username   :string           not null
#  password   :string           not null
#  created_at :datetime         not null
#  updated_at :datetime         not null
#

require 'rails_helper'

RSpec.describe User, type: :model do
  subject(:user) { User.first }

  it "is associated with playlists" do
    expect(user.playlists.first.name).to eq("Good Songs")
  end

  # This association is different than playlist tracks
  it "is associated with playlist songs" do
    album_id = Album.first.id
    expect(user.playlist_songs.first.album_id).to eq(album_id)
  end

  it "is associated with albums" do
    user = User.second
    expect(user.albums.first.name).to eq("Selected Ambient Works 85-92")
  end

  it "is associated with songs" do
    user = User.second
    album_id = Album.first.id
    expect(user.songs.first.album_id).to eq(album_id)
  end

  it "can be successfully destroyed" do
    expect { user.destroy }.not_to raise_error
  end
end