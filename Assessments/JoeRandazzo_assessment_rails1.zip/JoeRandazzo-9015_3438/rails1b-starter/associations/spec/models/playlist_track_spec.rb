# == Schema Information
#
# Table name: playlist_tracks
#
#  id          :bigint           not null, primary key
#  playlist_id :bigint           not null
#  song_id     :bigint           not null
#  created_at  :datetime         not null
#  updated_at  :datetime         not null
#

require 'rails_helper'

RSpec.describe PlaylistTrack, type: :model do
  subject(:playlist_track) { PlaylistTrack.first }

  it "is associated with a playlist" do
    expect(playlist_track.playlist.name).to eq("Good Songs")
  end

  it "is associated with a song" do
    expect(playlist_track.song.id).to eq(playlist_track.song_id)
  end
end