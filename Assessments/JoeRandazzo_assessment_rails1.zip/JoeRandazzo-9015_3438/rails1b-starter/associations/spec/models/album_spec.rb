# == Schema Information
#
# Table name: albums
#
#  id         :bigint           not null, primary key
#  name       :string           not null
#  year       :integer          not null
#  artist_id  :bigint           not null
#  created_at :datetime         not null
#  updated_at :datetime         not null
#

require 'rails_helper'

RSpec.describe Album, type: :model do
  subject(:album) { Album.first }

  it "is associated with an artist" do
    expect(album.artist.username).to eq("Aphex-Twin")
  end

  it "is associated with songs" do
    expect(album.songs.first.album_id).to eq(album.id)
  end

  it "can be successfully destroyed" do
    expect { album.destroy }.not_to raise_error
  end
end