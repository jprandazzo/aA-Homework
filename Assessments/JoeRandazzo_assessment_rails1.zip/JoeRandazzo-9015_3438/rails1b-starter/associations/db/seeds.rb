# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the bin/rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: "Star Wars" }, { name: "Lord of the Rings" }])
#   Character.create(name: "Luke", movie: movies.first)

ActiveRecord::Base.transaction do
  puts "Preparing #{Rails.env} environment"

  puts 'Destroying tables...'
  User.destroy_all
  Album.destroy_all
  Playlist.destroy_all
  Song.destroy_all
  PlaylistTrack.destroy_all

  puts 'Resetting id sequences...'
  %w(users albums playlists songs playlist_tracks).each do |table_name|
    ApplicationRecord.connection.reset_pk_sequence!(table_name)
  end

  puts 'Creating seed data...'
  ricky = User.create!(
    username: "ricky",
    password: "grade10"
  )

  aphex = User.create!(
    username: "Aphex-Twin",
    password: "starwars"
  )

  album1 = Album.create!(
    name: "Selected Ambient Works 85-92",
    year: 1992,
    artist_id: aphex.id
  )

  song1 = Song.create!(
    name: "Ptolemy",
    length: 434,
    album_id: album1.id
  )

  song2 = Song.create!(
    name: "Hedphelym",
    length: 363,
    album_id: album1.id
  )

  playlist1 = Playlist.create!(
    name: "Good Songs",
    user_id: ricky.id
  )

  track1 = PlaylistTrack.create!(
    playlist_id: playlist1.id,
    song_id: song1.id
  )

  track2 = PlaylistTrack.create!(
    playlist_id: playlist1.id,
    song_id: song2.id
  )

  puts "Done with #{Rails.env} environment!"
end