# == Schema Information
#
# Table name: songs
#
#  id         :bigint           not null, primary key
#  name       :string           not null
#  length     :integer          not null
#  album_id   :bigint           not null
#  created_at :datetime         not null
#  updated_at :datetime         not null
#

class Song < ApplicationRecord
    belongs_to :album, #passing
    class_name: :Album,
    foreign_key: :album_id

    has_many :playlist_tracks, #failing
    class_name: :PlaylistTrack,
    foreign_key: :song_id,
    dependent: :destroy

    has_one :artist, #passing
    through: :album,
    source: :artist
end