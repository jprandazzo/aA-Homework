# == Schema Information
#
# Table name: users
#
#  id         :bigint           not null, primary key
#  username   :string           not null
#  password   :string           not null
#  created_at :datetime         not null
#  updated_at :datetime         not null
#

class User < ApplicationRecord

    has_many :playlists,
    class_name: :Playlist,
    foreign_key: :user_id,
    dependent: :destroy

    has_many :playlist_songs,
    through: :playlists,
    source: :songs,
    dependent: :destroy

    has_many :albums,
    class_name: :Album,
    foreign_key: :artist_id,
    dependent: :destroy

    has_many :songs,
    through: :albums,
    source: :songs,
    dependent: :destroy
end