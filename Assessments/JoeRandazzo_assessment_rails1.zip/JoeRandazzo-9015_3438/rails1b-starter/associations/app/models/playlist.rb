# == Schema Information
#
# Table name: playlists
#
#  id         :bigint           not null, primary key
#  name       :string           not null
#  user_id    :bigint           not null
#  created_at :datetime         not null
#  updated_at :datetime         not null
#

class Playlist < ApplicationRecord
    belongs_to :user,
    class_name: :User,
    foreign_key: :user_id

    has_many :playlist_tracks, #failing
    class_name: :PlaylistTrack,
    foreign_key: :playlist_id,
    dependent: :destroy

    has_many :songs, #failing
    through: :playlist_tracks,
    source: :song

    has_many :albums,
    through: :songs,
    source: :album

    # has_many :artists

    has_many :artists,
    through: :albums,
    source: :artist

end