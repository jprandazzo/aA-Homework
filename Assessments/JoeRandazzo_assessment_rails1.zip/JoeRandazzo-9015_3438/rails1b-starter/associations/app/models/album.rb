# == Schema Information
#
# Table name: albums
#
#  id         :bigint           not null, primary key
#  name       :string           not null
#  year       :integer          not null
#  artist_id  :bigint           not null
#  created_at :datetime         not null
#  updated_at :datetime         not null
#

class Album < ApplicationRecord
    belongs_to :artist,
    class_name: :User,
    foreign_key: :artist_id

    has_many :playlist_tracks,
    through: :songs,
    source: :playlist_tracks
    
    has_many :songs,
    class_name: :Song,
    foreign_key: :album_id,
    dependent: :destroy
end