# == Schema Information
#
# Table name: actors
#
#  id         :bigint           not null, primary key
#  name       :string           not null
#  created_at :datetime         not null
#  updated_at :datetime         not null
#
# Table name: movies
#
#  id          :bigint           not null, primary key
#  title       :string           not null
#  yr          :integer          not null
#  score       :float            not null
#  votes       :integer          not null
#  director_id :bigint
#  created_at  :datetime         not null
#  updated_at  :datetime         not null
#
# Table name: castings
#
#  id         :bigint           not null, primary key
#  actor_id   :bigint           not null
#  movie_id   :bigint           not null
#  ord        :integer          not null
#  created_at :datetime         not null
#  updated_at :datetime         not null

# IMPORTANT:
# For all of the following problems return an ActiveRecord::Relation unless
# otherwise specified.

def godfather_movies
  # Find the id, title and year of each Godfather movie
  Movie.select(:id,:title,:yr).where("title like '%Godfather%'")
end

def michelle_movies
  # Find the id, title, and year of movies Michelle Pfeiffer has acted in.
  # Order them by score (descending) and title (descending).
  Movie.select(:id,:title,:yr).joins(:actors).where(actors: {name: 'Michelle Pfeiffer'})
  .order('movies.score desc,movies.title desc')
end

def actor_ids_from_blade_runner
  # Return an array (NOT an ActiveRecord:Association) of the `ids` of 
  # all the actors that were in the movie "Blade Runner".
  Movie.joins(:actors).where("movies.title = 'Blade Runner'").pluck('actors.id')
end

def best_years
  # Return an array of the years (NOT an ActiveRecord:Association) 
  # in which every movie released had a minimum rating of 8 or above.
  Movie.where('yr not in 
  (select yr from movies where score < 8)
  ').distinct.pluck(:yr)
end

def harrying_times
  # Return an array of the year(s) (NOT an ActiveRecord:Association) in which
  # Harrison Ford was in at least 2 movies.
  Movie.select(:yr).joins(:actors).where(actors: {name: 'Harrison Ford'}).group(:yr).having('count(movies.yr) >= 2').pluck(:yr)
end