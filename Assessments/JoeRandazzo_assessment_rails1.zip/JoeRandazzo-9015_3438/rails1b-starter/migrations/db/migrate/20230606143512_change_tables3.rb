class ChangeTables3 < ActiveRecord::Migration[7.0]
  def change
    add_column :albums, :year, :integer, null:false
  end
end
