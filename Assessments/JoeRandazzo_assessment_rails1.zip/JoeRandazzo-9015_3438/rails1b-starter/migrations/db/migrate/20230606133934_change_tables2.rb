class ChangeTables2 < ActiveRecord::Migration[7.0]
  def change
    rename_column :songs, :title, :name
    add_index :songs, :name
    remove_column :songs, :artist_id
    add_foreign_key :songs, :albums, column_name: :album_id
  end
end
