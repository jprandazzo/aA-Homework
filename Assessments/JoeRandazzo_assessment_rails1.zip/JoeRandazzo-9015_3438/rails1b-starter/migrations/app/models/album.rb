class Album < ApplicationRecord

end
