class Song < ApplicationRecord

end
