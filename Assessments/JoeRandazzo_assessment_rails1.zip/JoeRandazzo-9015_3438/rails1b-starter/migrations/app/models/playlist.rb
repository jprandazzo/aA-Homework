class Playlist < ApplicationRecord

end
