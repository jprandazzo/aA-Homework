class PlaylistTrack < ApplicationRecord

end
