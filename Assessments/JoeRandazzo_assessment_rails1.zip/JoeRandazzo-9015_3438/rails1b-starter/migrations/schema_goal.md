## `users`

| column name        | data type | details                        |
|:-------------------|:---------:|:-------------------------------|
| `id`               | bigint    | not null, primary key          |
| `username`         | string    | not null, indexed, unique      |
| `password`         | string    | not null                       |
| `created_at`       | datetime  | not null                       |
| `updated_at`       | datetime  | not null                       |

## `albums`

| column name        | data type | details                        |
|:-------------------|:---------:|:-------------------------------|
| `id`               | bigint    | not null, primary key          |
| `name`             | string    | not null                       |
| `year`             | integer   | not null                       |
| `artist_id`        | bigint    | not null, indexed, foreign key |
| `created_at`       | datetime  | not null                       |
| `updated_at`       | datetime  | not null                       |

## `songs`

| column name        | data type | details                        |
|:-------------------|:---------:|:-------------------------------|
| `id`               | bigint    | not null, primary key          |
| `name`             | string    | not null, indexed              |
| `length`           | integer   | not null                       |
| `album_id`         | bigint    | not null, indexed, foreign key |
| `created_at`       | datetime  | not null                       |
| `updated_at`       | datetime  | not null                       |

## `playlists`

| column name        | data type | details                        |
|:-------------------|:---------:|:-------------------------------|
| `id`               | bigint    | not null, primary key          |
| `name`             | string    | not null                       |
| `user_id`          | bigint    | not null, indexed              |
| `created_at`       | datetime  | not null                       |
| `updated_at`       | datetime  | not null                       |

## `playlist_tracks`

| column name        | data type | details                        |
|:-------------------|:---------:|:-------------------------------|
| `id`               | bigint    | not null, primary key          |
| `playlist_id`      | bigint    | not null, indexed, foreign key |
| `song_id`          | bigint    | not null, indexed, foreign key |
| `created_at`       | datetime  | not null                       |
| `updated_at`       | datetime  | not null                       |