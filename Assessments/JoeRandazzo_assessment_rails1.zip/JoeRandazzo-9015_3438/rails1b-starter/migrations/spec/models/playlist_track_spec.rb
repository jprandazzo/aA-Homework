require 'rails_helper'

RSpec.describe PlaylistTrack, type: :model do
  it "table exists" do 
    expect { PlaylistTrack.new }.not_to raise_error(ActiveRecord::StatementInvalid)
  end

  describe "'playlist_id' column" do
    it "exists with a type of 'bigint'" do
      expect(PlaylistTrack.column_names).to include('playlist_id')
      expect(PlaylistTrack.column_for_attribute('playlist_id').sql_type).to eq("bigint")
    end

    it "has a 'not null' constraint" do
      expect(PlaylistTrack.column_for_attribute('playlist_id').null).to be(false)
    end

    it "is indexed" do
      expect(ActiveRecord::Base.connection.index_exists?(:playlist_tracks, :playlist_id)).to be(true)
    end

    it "has a foreign key constraint" do
      schema = File.read('db/schema.rb')
      expect(/add_foreign_key \"playlist_tracks\", \"playlists\"/ =~ schema).not_to be(nil)
    end
  end

  describe "'song_id' column" do
    it "exists with a type of 'bigint'" do
      expect(PlaylistTrack.column_names).to include('song_id')
      expect(PlaylistTrack.column_for_attribute('song_id').sql_type).to eq("bigint")
    end

    it "has a 'not null' constraint" do
      expect(PlaylistTrack.column_for_attribute('song_id').null).to be(false)
    end

    it "is indexed" do
      expect(ActiveRecord::Base.connection.index_exists?(:playlist_tracks, :song_id)).to be(true)
    end

    it "has a foreign key constraint" do
      schema = File.read('db/schema.rb')
      expect(/add_foreign_key \"playlist_tracks\", \"songs\"/ =~ schema).not_to be(nil)
    end
  end

  it 'table has no additional columns (other than timestamps)' do
    expect(PlaylistTrack.column_names).to contain_exactly(
      'id', 'playlist_id', 'song_id', 'created_at', 'updated_at'
    )
  end
end
