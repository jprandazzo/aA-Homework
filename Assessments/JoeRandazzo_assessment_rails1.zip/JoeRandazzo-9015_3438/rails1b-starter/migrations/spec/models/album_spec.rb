require 'rails_helper'

RSpec.describe Album, type: :model do
  describe "'year' column" do
    it "has been added" do
      expect(Album.column_names).to include('year')
    end

    it "has type 'integer'" do
      expect(Album.column_for_attribute('year').type).to eq(:integer)
    end

    it "has a 'not null' constraint" do
      expect(Album.column_for_attribute('year').null).to be(false)
    end
  end

  describe "'artist_id' column" do
    it "has had an index added" do
      expect(ActiveRecord::Base.connection.index_exists?(:albums, :artist_id)).to be(true)
    end

    it "has had a foreign key constraint added" do
      schema = File.read('db/schema.rb')
      expect(/add_foreign_key \"albums\", \"users\", column: \"artist_id\"/ =~ schema).not_to be(nil)
    end
  end
end
